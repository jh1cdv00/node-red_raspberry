"""Common constants used all over the module."""
