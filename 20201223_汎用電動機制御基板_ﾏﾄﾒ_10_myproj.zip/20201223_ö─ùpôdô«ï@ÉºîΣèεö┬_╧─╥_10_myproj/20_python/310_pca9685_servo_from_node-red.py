#
#   ファイル名：30Out_pca9685_servo.py
#　　作成日　　：2020/12/5
#　　作成者　　：JH1CDV
#
#　　処理内容
#　　　　　入力：サーボ出力値を、JSON形式テキストで、シリアル入力
#　　　　　処理：サーボ出力値をJSON変数化し、サーボモータに出力
#　　　　　出力：無
#

# This example moves a servo its full range (180 degrees by default) and then back.
from board import SCL, SDA
import busio
# Import the PCA9685 module.
from adafruit_pca9685 import PCA9685
# This example also relies on the Adafruit motor library available here:
# https://github.com/adafruit/Adafruit_CircuitPython_Motor
from adafruit_motor import servo
import json
#import commands
import subprocess
import os
import sys

i2c = busio.I2C(SCL, SDA)
# Create a simple PCA9685 class instance.
pca = PCA9685(i2c)
pca.frequency = 50
# To get the full range of the servo you will likely need to adjust the min_pulse and max_pulse to
# match the stall points of the servo.
# This is an example for the Sub-micro servo: https://www.adafruit.com/product/2201
# servo7 = servo.Servo(pca.channels[7], min_pulse=580, max_pulse=2480)
# This is an example for the Micro Servo - High Powered, High Torque Metal Gear:
#   https://www.adafruit.com/product/2307
# servo7 = servo.Servo(pca.channels[7], min_pulse=600, max_pulse=2400)
# This is an example for the Standard servo - TowerPro SG-5010 - 5010:
#   https://www.adafruit.com/product/155
# servo7 = servo.Servo(pca.channels[7], min_pulse=600, max_pulse=2500)
# This is an example for the Analog Feedback Servo: https://www.adafruit.com/product/1404
# servo7 = servo.Servo(pca.channels[7], min_pulse=600, max_pulse=2600)

# JSON変数定義        数値：0~45~90度
s0 = '{"servo0":0,"servo1":0,"servo2":0,"servo3":0,"servo4":0,"servo5":0,"servo6":0,"servo7":0}'
s45 = '{"servo0":45,"servo1":45,"servo2":45,"servo3":45,"servo4":45,"servo5":45,"servo6":45,"servo7":45}'
s90 = '{"servo0":90,"servo1":90,"servo2":90,"servo3":90,"servo4":90,"servo5":90,"servo6":90,"servo7":90}'
s180 = '{"servo0":180,"servo1":180,"servo2":180,"servo3":180,"servo4":180,"servo5":180,"servo6":180,"servo7":180}'

# command　arg[1]で、変数入力
arg1 = ''
argv = sys.argv
argc = len(argv)
s_in = sys.argv[1]
print(s_in)

# JSON変数入力
#j = json.loads(s45)
j = json.loads(s_in)
print(j)

# The pulse range is 1000 - 2000 by default.
servo0 = servo.Servo(pca.channels[0])
servo1 = servo.Servo(pca.channels[1])
servo2 = servo.Servo(pca.channels[2])
servo3 = servo.Servo(pca.channels[3])
servo4 = servo.Servo(pca.channels[4])
servo5 = servo.Servo(pca.channels[5])
servo6 = servo.Servo(pca.channels[6])
servo7 = servo.Servo(pca.channels[7])

# サーボに出力
servo0.angle = j['servo0']
servo1.angle = j['servo1']
#servo2.angle = j['servo2']
#servo3.angle = j['servo3']
#servo4.angle = j['servo4']
#servo5.angle = j['servo5']
#servo6.angle = j['servo6']
#servo7.angle = j['servo7']



#for i in range(180):
#    servo0.angle = i
#for i in range(180):
#    servo0.angle = 180 - i



pca.deinit()
