# This advanced example can be used to compute a more precise reference_clock_speed. Use an
# oscilloscope or logic analyzer to measure the signal frequency and type the results into the
# prompts. At the end it'll give you a more precise value around 25 mhz for your reference clock
# speed.

import time

from board import SCL, SDA
import busio

# Import the PCA9685 module.
from adafruit_pca9685 import PCA9685
from adafruit_motor import motor

# Create the I2C bus interface.
i2c_bus = busio.I2C(SCL, SDA)
# Create a simple PCA9685 class instance.
pca = PCA9685(i2c_bus)
# Set the PWM frequency to 100hz.
pca.frequency = 100

# Set motor1
pwm_channe1 = pca.channels[8]
channel1_1 = pca.channels[10]
channel1_2 = pca.channels[9]
pwm_channe1.duty_cycle = 0xffff # hold high
motor1 = motor.DCMotor(channel1_1, channel1_2)

# Set motor2
pwm_channe2 = pca.channels[13]
channel2_1 = pca.channels[11]
channel2_2 = pca.channels[12]
pwm_channe2.duty_cycle = 0xffff # hold high
motor2 = motor.DCMotor(channel2_1, channel2_2)

motor1.throttle = 0.5
motor2.throttle = 0.5
time.sleep(0.5)
motor1.throttle = -0.5
motor2.throttle = -0.5