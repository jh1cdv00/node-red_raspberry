#
#   ファイル名：50_pca9685_dc_motor_to_node-red.py
#　　作成日　　：2020/12/12
#　　作成者　　：JH1CDV
#
#　　処理内容
#　　　　　入力：DCモータ出力値を、JSON形式テキストで、シリアル入力
#　　　　　処理：DCモータ出力値をJSON変数化し、DCモータに出力
#　　　　　出力：無
#

# This advanced example can be used to compute a more precise reference_clock_speed. Use an
# oscilloscope or logic analyzer to measure the signal frequency and type the results into the
# prompts. At the end it'll give you a more precise value around 25 mhz for your reference clock
# speed.

import time

from board import SCL, SDA
import busio

# Import the PCA9685 module.
from adafruit_pca9685 import PCA9685
from adafruit_motor import motor
#import commands
import subprocess
import os
import sys
import json

# JSON変数定義        数値：0~45~90度
m00 = '{"m1":0,"m2":0,"t":1.0}'
m05 = '{"m1":0.5,"m2":0.5,"t":1.0}'
# command　arg[1]で、変数入力
arg1 = ''
argv = sys.argv
argc = len(argv)
s_in = sys.argv[1]
print(s_in)

# JSON変数入力
j = json.loads(m05)
j = json.loads(s_in)
print(j)

# Create the I2C bus interface.
i2c_bus = busio.I2C(SCL, SDA)
# Create a simple PCA9685 class instance.
pca = PCA9685(i2c_bus)
# Set the PWM frequency to 100hz.
pca.frequency = 100

# Set motor1
pwm_channe1 = pca.channels[8]
channel1_1 = pca.channels[10]
channel1_2 = pca.channels[9]
pwm_channe1.duty_cycle = 0xffff # hold high
motor1 = motor.DCMotor(channel1_1, channel1_2)

# Set motor2
pwm_channe2 = pca.channels[13]
channel2_1 = pca.channels[11]
channel2_2 = pca.channels[12]
pwm_channe2.duty_cycle = 0xffff # hold high
motor2 = motor.DCMotor(channel2_1, channel2_2)

# motor2は、取付向きが１と逆なので、逆回転に！！！
motor1.throttle = float(j['m1'])
motor2.throttle = (float(j['m2']) * -1.0)


#time.sleep(1)
time.sleep(float(j['t']))
motor1.throttle = 0.0
motor2.throttle = 0.0

#for test
#motor1.throttle = 0.5
#motor2.throttle = 0.5
#time.sleep(0.5)
#motor1.throttle = -0.5
#motor2.throttle = -0.5