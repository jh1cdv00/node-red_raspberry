# This example is for use on (Linux) computers that are using CPython with
# Adafruit Blinka to support CircuitPython libraries. CircuitPython does
# not support PIL/pillow (python imaging library)!
#
# Ported to Pillow by Melissa LeBlanc-Williams for Adafruit Industries from Code available at:
# https://learn.adafruit.com/adafruit-oled-displays-for-raspberry-pi/programming-your-display

# Imports the necessary libraries...
import board
import digitalio
from PIL import Image, ImageDraw, ImageFont
#import adafruit_ssd1306
import adafruit_ssd1306

#import commands
import subprocess
import os
import sys
import json
import time

# Setting some variables for our reset pin etc.
RESET_PIN = digitalio.DigitalInOut(board.D4)

# Very important... This lets py-gaugette 'know' what pins to use in order to reset the display
i2c = board.I2C()
#oled = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3D, reset=RESET_PIN)
oled = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C, reset=RESET_PIN)

# Clear display.
oled.fill(0)
oled.show()

# JSON変数定義       
L00 = '{"line1":"初期値＿１行目","line2":"line2","line3":"line3","line4":"line4"}'
L10 = '{"line1":"cmd_line1","line2":"line2","line3":"line3","line4":"line4"}'

# command　arg[1]で、変数入力
arg1 = ''
argv = sys.argv
argc = len(argv)
s_in = sys.argv[1]
print(s_in)

# JSON変数入力
j = json.loads(L00)
j = json.loads(s_in)
print(j)


# Create blank image for drawing.
image = Image.new("1", (oled.width, oled.height))
draw = ImageDraw.Draw(image)

# Load a font in 2 different sizes.
#font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 28)
#font2 = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14)
font = ImageFont.truetype("/usr/share/fonts/truetype/takao-gothic/TakaoPGothic.ttf", 28)
font2 = ImageFont.truetype("/usr/share/fonts/truetype/takao-gothic/TakaoPGothic.ttf", 14)

# Draw the text
draw.text((0, 0), str(j['line1']), font=font2, fill=255)
draw.text((0, 16),str(j['line2']), font=font2, fill=255)
draw.text((0, 32),str(j['line3']), font=font2, fill=255)
draw.text((0, 48),str(j['line4']), font=font2, fill=255)
# Display image
oled.image(image)
oled.show()
