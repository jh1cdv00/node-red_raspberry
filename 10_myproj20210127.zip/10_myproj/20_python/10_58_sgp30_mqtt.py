""" Example for using the SGP30 with CircuitPython and the Adafruit library"""
#
#
#
# 
# #　　作成日　　：2021/1/21
# #　　  
# #　　作成者　　：JH1CDV
#
#　　処理内容
#　　　　　入力：sgp30入力値
#　　　　　処理：アナログ入力値をJSON変数化
#　　　　　出力：アナログ入力値を、JSON形式テキストで、mqtt出力
#
# JSON変数定義
# JSON変数にアナログ入力値を代入
# JSON変数：アナログ入力値をシリアル出力
#   
#    -----------------------------------------------------------------------
# The following command will install MQTT Python library:
# sudo pip install paho-mqtt
#
import time
import board
import busio
import lib.adafruit_sgp30
# 追加
import os
import sys
import paho.mqtt.client as mqtt
import json

i2c = busio.I2C(board.SCL, board.SDA, frequency=100000)

# Create library object on our I2C port
sgp30 = lib.adafruit_sgp30.Adafruit_SGP30(i2c)

#THINGSBOARD_HOST = 'demo.thingsboard.io'
#ACCESS_TOKEN = 'DHT22_DEMO_TOKEN'
Local_HOST = 'localhost'
#ACCESS_TOKEN = 'DHT22_DEMO_TOKEN'

#sensor_data = {'temperature': 0, 'humidity': 0}
sensor_data = {'sgp30_eCO2': 0, 'sgp30_TVOC': 0}


next_reading = time.time() 
client = mqtt.Client()

# Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
#client.connect(THINGSBOARD_HOST, 1883, 60)
client.connect(Local_HOST, 1883, 60)

client.loop_start()




print("SGP30 serial #", [hex(i) for i in sgp30.serial])

sgp30.iaq_init()
#sgp30.set_iaq_baseline(0x8973, 0x8AAE)

elapsed_sec = 0

while True:
    #print("eCO2 = %d ppm \t TVOC = %d ppb" % (sgp30.eCO2, sgp30.TVOC))
    #sensor_data['temperature'] = temperature
    #sensor_data['humidity'] = humidity
    sensor_data['sgp30_eCO2'] = sgp30.eCO2
    sensor_data['sgp30_TVOC'] = sgp30.TVOC
    print(json.dumps(sensor_data))
    
    # Sending humidity and temperature data to ThingsBoard
    #client.publish('v1/devices/me/telemetry', json.dumps(sensor_data), 1)
    client.publish('sgp30', json.dumps(sensor_data), 1)


    time.sleep(1)
    elapsed_sec += 1
    if elapsed_sec > 10:
        elapsed_sec = 0
        print(
            "**** Baseline values: eCO2 = 0x%x, TVOC = 0x%x"
            % (sgp30.baseline_eCO2, sgp30.baseline_TVOC)
        )
