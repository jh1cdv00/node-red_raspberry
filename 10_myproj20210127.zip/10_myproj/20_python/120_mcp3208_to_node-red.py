#
#   ファイル名：20In_mcp3208_to_node-red.py
#　　作成日　　：2020/12/5
#　　作成者　　：JH1CDV
#
#　　処理内容
#　　　　　入力：MCP3208の8ch、12bit　アナログ入力値
#　　　　　処理：アナログ入力値をJSON変数化
#　　　　　出力：アナログ入力値を、JSON形式テキストで、シリアル出力
#
# JSON変数定義
# JSON変数にアナログ入力値を代入
# JSON変数：アナログ入力値をシリアル出力

import busio
import digitalio
import board
import adafruit_mcp3xxx.mcp3008 as MCP
from adafruit_mcp3xxx.analog_in import AnalogIn
import json

# create the spi bus
spi = busio.SPI(clock=board.SCK, MISO=board.MISO, MOSI=board.MOSI)
# create the cs (chip select)
#cs = digitalio.DigitalInOut(board.D5)
cs = digitalio.DigitalInOut(board.D8)
# create the mcp object
mcp = MCP.MCP3008(spi, cs)

# JSON変数定義
s = '{"ch0":0.0,"ch1":0.0,"ch2":0.0,"ch3":0.0,"ch4":0.0,"ch5":0.0,"ch6":0.0,"ch7":0.0}'
j = json.loads(s)
#print(j)

# create an analog input channel on pin 0
#chan = AnalogIn(mcp, MCP.P0)
#print("Raw ADC Value: ", chan.value)
#print("ADC Voltage: " + str(chan.voltage) + "V")

# create an analog input channel on pin 0
ch0 = AnalogIn(mcp, MCP.P0)
ch1 = AnalogIn(mcp, MCP.P1)
ch2 = AnalogIn(mcp, MCP.P2)
ch3 = AnalogIn(mcp, MCP.P3)
ch4 = AnalogIn(mcp, MCP.P4)
ch5 = AnalogIn(mcp, MCP.P5)
ch6 = AnalogIn(mcp, MCP.P6)
ch7 = AnalogIn(mcp, MCP.P7)

# JSON変数にアナログ入力値を代入
j['ch0'] = ch0.value
j['ch1'] = ch1.value
j['ch2'] = ch2.value
j['ch3'] = ch3.value
j['ch4'] = ch4.value
j['ch5'] = ch5.value
j['ch6'] = ch6.value
j['ch7'] = ch7.value

#print("ch0", ch0.value, ch1.value, ch2.value, ch3.value)
#print("ch4", ch4.value, ch5.value, ch6.value, ch7.value)

# JSON変数：アナログ入力値をシリアル出力
print(j)
