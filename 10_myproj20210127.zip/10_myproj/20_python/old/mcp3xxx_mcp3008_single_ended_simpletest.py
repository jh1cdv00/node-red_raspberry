import busio
import digitalio
import board
import adafruit_mcp3xxx.mcp3008 as MCP
from adafruit_mcp3xxx.analog_in import AnalogIn

# create the spi bus
spi = busio.SPI(clock=board.SCK, MISO=board.MISO, MOSI=board.MOSI)

# create the cs (chip select)
#cs = digitalio.DigitalInOut(board.D5)
cs = digitalio.DigitalInOut(board.D8)


# create the mcp object
mcp = MCP.MCP3008(spi, cs)

# create an analog input channel on pin 0
chan = AnalogIn(mcp, MCP.P0)

print("Raw ADC Value: ", chan.value)
print("ADC Voltage: " + str(chan.voltage) + "V")

# create an analog input channel on pin 0
ch0 = AnalogIn(mcp, MCP.P0)
ch1 = AnalogIn(mcp, MCP.P1)
ch2 = AnalogIn(mcp, MCP.P2)
ch3 = AnalogIn(mcp, MCP.P3)
ch4 = AnalogIn(mcp, MCP.P4)
ch5 = AnalogIn(mcp, MCP.P5)
ch6 = AnalogIn(mcp, MCP.P6)
ch7 = AnalogIn(mcp, MCP.P7)

print("ch0", ch0.value, ch1.value, ch2.value, ch3.value)
print("ch4", ch4.value, ch5.value, ch6.value, ch7.value)
