#!/usr/bin/env python
from gpiozero import MCP3208
Vref = 3.29476

pot0 = MCP3208(channel=0)
print(str(pot0.value * Vref) + "V")
pot6 = MCP3208(channel=6)
print(str(pot6.value * Vref) + "V")
pot7 = MCP3208(channel=7)
print(str(pot7.value * Vref) + "V")