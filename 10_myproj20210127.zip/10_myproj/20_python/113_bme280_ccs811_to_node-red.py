#!/usr/bin/env python
#
#
#
# 
# #　　作成日　　：2021/1/7
#　　作成者　　：JH1CDV
#
#　　処理内容
#　　　　　入力：bme280入力値
#　　　　　処理：アナログ入力値をJSON変数化
#　　　　　出力：アナログ入力値を、JSON形式テキストで、シリアル出力
#
# JSON変数定義
# JSON変数にアナログ入力値を代入
# JSON変数：アナログ入力値をシリアル出力

import time

import board
import busio
import adafruit_bme280
import json
import adafruit_ccs811

# Create library object using our Bus I2C port
i2c = busio.I2C(board.SCL, board.SDA)
bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c)
ccs811 = adafruit_ccs811.CCS811(i2c)

# OR create library object using our Bus SPI port
# spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
# bme_cs = digitalio.DigitalInOut(board.D10)
# bme280 = adafruit_bme280.Adafruit_BME280_SPI(spi, bme_cs)

# change this to match the location's pressure (hPa) at sea level
bme280.sea_level_pressure = 1013.25

# JSON変数定義
#s = '{"Temp": 15.0,"Humi": 41.4,"Press": 1010.520,"Alti": 22.75}'
s = '{"Temp": 15.0,"Humi": 41.4,"Press": 1010.520}'

j = json.loads(s)
#print(j)
# Wait for the sensor to be ready
while not ccs811.data_ready:
    pass


#while True:
#print("\nTemperature: %0.1f C" % bme280.temperature)
#print("Humidity: %0.1f %%" % bme280.humidity)
#print("Pressure: %0.1f hPa" % bme280.pressure)
#print("Altitude = %0.2f meters" % bme280.altitude)
print("CO2: {} PPM, TVOC: {} PPB".format(ccs811.eco2, ccs811.tvoc))
#time.sleep(2)
# 
#  # JSON変数にアナログ入力値を代入
hum = bme280.humidity
temp = bme280.temperature
press = bme280.pressure



# JSON変数にアナログ入力値を代入
j['Humi'] = hum
j['Temp'] = temp
j['Press'] = press
# JSON変数：アナログ入力値をシリアル出力
print(j)




