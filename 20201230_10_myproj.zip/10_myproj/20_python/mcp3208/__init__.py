
from mcp3208.MCP3208 import MCP3208
from mcp3208.version import __version__

__author__ = 'Kevin J. Walchko'
__license__ = 'MIT'
