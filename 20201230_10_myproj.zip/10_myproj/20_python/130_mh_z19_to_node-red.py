import mh_z19
out = mh_z19.read()
print(out)