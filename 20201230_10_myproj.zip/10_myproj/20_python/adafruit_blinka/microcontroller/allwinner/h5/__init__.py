"""Definition for the AllWinner H5 chip"""
