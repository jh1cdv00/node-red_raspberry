"""Rock Pi Boards definition from Radxa"""
